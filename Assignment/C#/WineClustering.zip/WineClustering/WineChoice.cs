namespace WineClustering
{
    public class WineChoice
    {
        public int offerId;
        public double choice;

        public WineChoice(int offerId, double choice)
        {
            this.offerId = offerId;
            this.choice = choice;
        }
    }
}